"""
DecodeLabs Project 4 — Non-Fungible Tokens (NFTs) with Metadata
-----------------------------------------------------------------
A Python/Flask simulation of an ERC-721 contract.

- safeMint()  -> POST /api/mint
- ownerOf()   -> GET  /api/owner/<token_id>
- tokenURI()  -> off-chain metadata resolved via a simple file path
                 under static/metadata/<token_id>.json (simulates IPFS)
- transferFrom() -> POST /api/transfer
- Full state (owners, balances, event log) lives in memory and is
  mirrored to data/state.json so it survives server restarts.
"""

import json
import os
import time
import hashlib
import secrets
from datetime import datetime, timezone

from flask import Flask, jsonify, request, render_template

app = Flask(__name__)

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
METADATA_DIR = os.path.join(BASE_DIR, "static", "metadata")
STATE_FILE = os.path.join(BASE_DIR, "data", "state.json")

NULL_ADDRESS = "0x0000000000000000000000000000000000000000"
CONTRACT_ADDRESS = "0x4e29A4fC53aD92D2E68e82B02d6D6d953925F4C1"
DEFAULT_WALLET = "0x71C7656EC7ab88b098defB751B7401B5f6d8976"

CUTE_FUR = ["Pastel Pink", "Mint Green", "Sky Blue", "Lavender Dream", "Peach Fizz", "Buttercream"]
CUTE_EYES = ["Sparkle Star", "Anime Wink", "Heterochromia", "Sleepy Blink"]
CUTE_ACCESSORY = ["Crown", "Bow Tie", "Round Glasses", "Flower Crown", "None"]
CUTE_BG = ["Sakura Blossom", "Cosmic Nebula", "Sunshine Cafe", "Mint Meadow", "Cloud Nine"]

# ---------------------------------------------------------------------------
# In-memory "chain state" (mirrors what a Solidity contract's storage would hold)
# ---------------------------------------------------------------------------
state = {
    "owners": {},          # tokenId(str) -> address
    "token_uris": {},      # tokenId(str) -> file path (tokenURI)
    "balances": {},        # address -> count
    "events": [],          # transfer log
    "block_height": 19482105,
    "next_token_id": 1,
}


def save_state():
    os.makedirs(os.path.dirname(STATE_FILE), exist_ok=True)
    with open(STATE_FILE, "w") as f:
        json.dump(state, f, indent=2)


def load_state():
    if os.path.exists(STATE_FILE):
        with open(STATE_FILE) as f:
            loaded = json.load(f)
            state.update(loaded)


def now_iso():
    return datetime.now(timezone.utc).isoformat()


def gen_tx_hash():
    return "0x" + secrets.token_hex(32)


def gen_ipfs_cid(payload: str) -> str:
    digest = hashlib.sha256(payload.encode()).hexdigest()
    return "Qm" + digest[:44]


def write_metadata_file(token_id: int, metadata: dict) -> str:
    """Writes metadata to a JSON file on disk and returns its relative path.
    This simulates the ERC-721 'off-chain metadata' pattern: the contract
    only stores a pointer (tokenURI); the actual JSON lives off-chain."""
    os.makedirs(METADATA_DIR, exist_ok=True)
    filename = f"{token_id}.json"
    path = os.path.join(METADATA_DIR, filename)
    with open(path, "w") as f:
        json.dump(metadata, f, indent=2)
    return f"/static/metadata/{filename}"


def error(name, message, status=400, **extra):
    body = {"errorName": name, "message": message}
    body.update(extra)
    return jsonify(body), status


# ---------------------------------------------------------------------------
# Routes — frontend
# ---------------------------------------------------------------------------
@app.route("/")
def index():
    return render_template("index.html")


# ---------------------------------------------------------------------------
# Routes — API (the "contract interface")
# ---------------------------------------------------------------------------
@app.route("/api/health")
def health():
    return jsonify({"status": "ok", "timestamp": now_iso()})


@app.route("/api/stats")
def stats():
    total_supply = len(state["owners"])
    total_holders = len(set(state["owners"].values()))
    return jsonify({
        "networkName": "DecodeLabs Testnet (EVM Sepolia)",
        "chainId": 11155111,
        "blockHeight": state["block_height"],
        "gasPriceGwei": 18.5,
        "totalSupply": total_supply,
        "totalHolders": total_holders,
        "contractAddress": CONTRACT_ADDRESS,
        "nullAddress": NULL_ADDRESS,
    })


@app.route("/api/traits")
def traits():
    return jsonify({
        "fur": CUTE_FUR,
        "eyes": CUTE_EYES,
        "accessory": CUTE_ACCESSORY,
        "background": CUTE_BG,
    })


@app.route("/api/tokens")
def list_tokens():
    tokens = []
    for tid_str, owner in state["owners"].items():
        tid = int(tid_str)
        uri = state["token_uris"][tid_str]
        meta_path = os.path.join(BASE_DIR, uri.lstrip("/"))
        metadata = {}
        if os.path.exists(meta_path):
            with open(meta_path) as f:
                metadata = json.load(f)
        tokens.append({
            "tokenId": tid,
            "owner": owner,
            "tokenURI": uri,
            "metadata": metadata,
        })
    tokens.sort(key=lambda t: t["tokenId"])
    return jsonify(tokens)


@app.route("/api/owner/<int:token_id>")
def owner_of(token_id):
    """Simulates the ERC-721 ownerOf() view function."""
    tid = str(token_id)
    if tid not in state["owners"]:
        return error(
            "ERC721NonexistentToken",
            f"ERC721: owner query for nonexistent token #{token_id}",
            404,
            tokenId=token_id,
        )

    uri = state["token_uris"][tid]
    meta_path = os.path.join(BASE_DIR, uri.lstrip("/"))
    metadata = {}
    if os.path.exists(meta_path):
        with open(meta_path) as f:
            metadata = json.load(f)

    history = [e for e in state["events"] if e["tokenId"] == token_id]

    return jsonify({
        "tokenId": token_id,
        "owner": state["owners"][tid],
        "tokenURI": uri,
        "metadata": metadata,
        "history": history,
    })


@app.route("/api/metadata/<int:token_id>")
def metadata_of(token_id):
    """Simulates resolving tokenURI() to its off-chain JSON document."""
    tid = str(token_id)
    if tid not in state["token_uris"]:
        return error("ERC721NonexistentToken", "Requested metadata does not exist.", 404)
    uri = state["token_uris"][tid]
    meta_path = os.path.join(BASE_DIR, uri.lstrip("/"))
    with open(meta_path) as f:
        return jsonify(json.load(f))


@app.route("/api/mint", methods=["POST"])
def mint():
    """Simulates the safeMint() function of an ERC-721 contract."""
    body = request.get_json(force=True, silent=True) or {}
    name = (body.get("name") or "").strip()
    description = body.get("description") or "An adorable digital collectible minted on DecodeLabs Testnet."
    recipient = (body.get("recipient") or "").strip()
    fur = body.get("fur") or CUTE_FUR[0]
    eyes = body.get("eyes") or CUTE_EYES[0]
    accessory = body.get("accessory") or "None"
    background = body.get("background") or CUTE_BG[0]

    if not name or not recipient:
        return error("InvalidParameters", "Name and recipient address are required.")

    if recipient.lower() == NULL_ADDRESS.lower():
        return error(
            "ERC721InvalidReceiver",
            "ERC721: mint to the zero address is strictly forbidden.",
            address=NULL_ADDRESS,
        )

    token_id = state["next_token_id"]
    state["next_token_id"] += 1

    attributes = [
        {"trait_type": "Fur", "value": fur},
        {"trait_type": "Eyes", "value": eyes},
        {"trait_type": "Accessory", "value": accessory},
        {"trait_type": "Background", "value": background},
    ]

    # Rarity is derived from how many "premium" traits were chosen — a bit of
    # deterministic state manipulation, matching the project's key skills.
    premium_count = sum(1 for t in [fur, eyes, accessory] if t not in ("Buttercream", "Sleepy Blink", "None"))
    rarity = ["Common", "Rare", "Epic", "Legendary"][min(premium_count, 3)]
    attributes.append({"trait_type": "Rarity", "value": rarity})

    raw_metadata = {
        "name": name,
        "description": description,
        "attributes": attributes,
        "compiler": "DecodeLabs Solidity safeMint Engine v1.0",
        "minted_at": int(time.time()),
    }
    cid = gen_ipfs_cid(json.dumps(raw_metadata, sort_keys=True))
    raw_metadata["ipfs_cid"] = cid
    raw_metadata["image"] = f"generated://cat-avatar/{token_id}"

    token_uri = write_metadata_file(token_id, raw_metadata)

    state["block_height"] += 1
    state["owners"][str(token_id)] = recipient
    state["token_uris"][str(token_id)] = token_uri
    state["balances"][recipient] = state["balances"].get(recipient, 0) + 1

    tx_hash = gen_tx_hash()
    event = {
        "id": f"evt-{token_id}-{int(time.time() * 1000)}",
        "from": NULL_ADDRESS,
        "to": recipient,
        "tokenId": token_id,
        "txHash": tx_hash,
        "blockNumber": state["block_height"],
        "timestamp": now_iso(),
        "tokenName": name,
    }
    state["events"].insert(0, event)
    save_state()

    return jsonify({
        "success": True,
        "message": f"Token #{token_id} successfully minted to {recipient}",
        "tokenId": token_id,
        "owner": recipient,
        "tokenURI": token_uri,
        "metadata": raw_metadata,
        "event": event,
        "gasUsed": 142580,
    })


@app.route("/api/transfer", methods=["POST"])
def transfer():
    """Simulates safeTransferFrom()."""
    body = request.get_json(force=True, silent=True) or {}
    from_addr = (body.get("from") or "").strip()
    to_addr = (body.get("to") or "").strip()
    token_id = body.get("tokenId")

    try:
        tid = int(token_id)
    except (TypeError, ValueError):
        return error("InvalidParameters", "A valid tokenId is required.")

    tid_str = str(tid)
    if tid_str not in state["owners"]:
        return error("ERC721NonexistentToken", f"ERC721: token #{tid} does not exist.", 404)

    current_owner = state["owners"][tid_str]
    if current_owner.lower() != from_addr.lower():
        return error(
            "ERC721IncorrectOwner",
            f"ERC721: transfer from incorrect owner. {from_addr} does not own token #{tid}.",
        )

    if to_addr.lower() == NULL_ADDRESS.lower():
        return error("ERC721InvalidReceiver", "ERC721: transfer to the zero address is forbidden.")

    state["balances"][from_addr] = max(0, state["balances"].get(from_addr, 1) - 1)
    state["balances"][to_addr] = state["balances"].get(to_addr, 0) + 1
    state["owners"][tid_str] = to_addr
    state["block_height"] += 1

    tx_hash = gen_tx_hash()
    event = {
        "id": f"evt-tr-{tid}-{int(time.time() * 1000)}",
        "from": from_addr,
        "to": to_addr,
        "tokenId": tid,
        "txHash": tx_hash,
        "blockNumber": state["block_height"],
        "timestamp": now_iso(),
        "tokenName": "",
    }
    state["events"].insert(0, event)
    save_state()

    return jsonify({
        "success": True,
        "message": f"Token #{tid} successfully transferred to {to_addr}",
        "newOwner": to_addr,
        "event": event,
    })


@app.route("/api/events")
def events():
    return jsonify(state["events"][:25])


def seed_if_empty():
    """Seeds a couple of starter NFTs on first launch so the gallery isn't empty."""
    if state["owners"]:
        return
    seed_data = [
        {"name": "CryptoKitty #1 — Princess Sakura", "fur": "Pastel Pink", "eyes": "Sparkle Star",
         "accessory": "Crown", "background": "Sakura Blossom",
         "description": "An adorable legendary feline with royal sakura blossoms."},
        {"name": "Starry Neko #2", "fur": "Sky Blue", "eyes": "Heterochromia",
         "accessory": "Round Glasses", "background": "Cosmic Nebula",
         "description": "A cosmic kitty roaming through distant galaxies."},
        {"name": "Boba Cat #3", "fur": "Buttercream", "eyes": "Anime Wink",
         "accessory": "Bow Tie", "background": "Sunshine Cafe",
         "description": "A sweet buttercream cat sipping fresh boba tea."},
    ]
    with app.test_request_context():
        for item in seed_data:
            with app.test_client() as c:
                c.post("/api/mint", json={**item, "recipient": DEFAULT_WALLET})


if __name__ == "__main__":
    load_state()
    seed_if_empty()
    port = int(os.environ.get("PORT", 5000))
    print(f"Server listening on http://127.0.0.1:{port}")
    app.run(host="0.0.0.0", port=port, debug=True)
