# Kitty Mint Studio — DecodeLabs Project 4

**Non-Fungible Tokens (NFTs) with Metadata** — Industrial Training Kit, Batch 2026

A Python (Flask) backend simulating an ERC-721 smart contract, paired with a
cute pastel HTML/CSS/JS frontend. Meets all Project 4 requirements:

- ✅ Implements the ERC-721 `safeMint` and `ownerOf` methods (`POST /api/mint`, `GET /api/owner/<id>`)
- ✅ Links each token to off-chain metadata via a simple file path (`static/metadata/<id>.json` — simulating a `tokenURI`)
- ✅ Clearly displays ownership data after every mint/transfer (gallery, ledger lookup, live event log)
- ✅ Demonstrates unique-asset handling, metadata management, and on-chain state manipulation (mappings for owners/balances, transfer history)

## Project structure

```
nft-metadata-engine/
├── app.py                  # Flask backend — the "smart contract"
├── requirements.txt
├── templates/
│   └── index.html          # single-page frontend
├── static/
│   ├── css/style.css       # pastel neumorphic styling
│   ├── js/script.js        # trait pickers, SVG cat generator, API calls
│   └── metadata/           # off-chain metadata JSON files (created at runtime)
└── data/
    └── state.json          # persisted contract state (created at runtime)
```

## Run locally (Windows PowerShell)

1. Open the folder in VS Code and open a PowerShell terminal in it.
2. Create and activate a virtual environment:
   ```powershell
   python -m venv venv
   venv\Scripts\Activate.ps1
   ```
   If PowerShell blocks the activation script, run this once first:
   ```powershell
   Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
   ```
3. Install dependencies:
   ```powershell
   pip install -r requirements.txt
   ```
4. Run the app:
   ```powershell
   python app.py
   ```
5. Open your browser to:
   ```
   http://127.0.0.1:5000
   ```
   (not `0.0.0.0:5000` — browsers can't open that address directly)

## What it does

- **Mint Console** — pick fur, eyes, accessory, and background via chip buttons, see a live SVG preview, then mint. Backend assigns a token ID, computes a deterministic SHA-256 IPFS-style CID, writes the metadata to a JSON file, and updates the in-memory owner/balance mappings.
- **Ledger Lookup** — simulates `ownerOf()`: enter a token ID to see its owner, tokenURI, and transfer history. Returns a proper `ERC721NonexistentToken` error for unminted IDs.
- **Transfer Ownership** — simulates `safeTransferFrom()` with ownership and zero-address checks.
- **Collection Gallery** — every minted kitty, rendered live from its metadata (no image files — cats are generated as SVG from trait data).
- **Live Event Log** — recent mint/transfer events, auto-refreshing.
- **Stats bar** — mock chain stats (block height, gas price, supply, holders).

No API keys or external services required — everything runs locally.
