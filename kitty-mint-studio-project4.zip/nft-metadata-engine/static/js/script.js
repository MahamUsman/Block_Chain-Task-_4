// ==========================================================================
// Kitty Mint Studio — frontend logic (vanilla JS, no build step)
// ==========================================================================

const DEMO_WALLET = "0x71C7656EC7ab88b098defB751B7401B5f6d8976";

const FUR_COLORS = {
  "Pastel Pink": "#FFC9DE",
  "Mint Green": "#B9F2D9",
  "Sky Blue": "#BFE1FA",
  "Lavender Dream": "#DCCEFA",
  "Peach Fizz": "#FFD9C2",
  "Buttercream": "#FFF1C6",
};
const BG_GRADIENTS = {
  "Sakura Blossom": ["#FFE3EE", "#FFC2DC"],
  "Cosmic Nebula": ["#DCE8FF", "#C6B6F5"],
  "Sunshine Cafe": ["#FFF3D6", "#FFDE9C"],
  "Mint Meadow": ["#DFFBEE", "#B7EFD3"],
  "Cloud Nine": ["#EAF4FF", "#D6E9FF"],
};

let traitOptions = null;
let selected = { fur: null, eyes: null, accessory: "None", background: null };

// ---------------------------------------------------------------------------
// Cat SVG generator — builds a cute face purely from trait strings
// ---------------------------------------------------------------------------
function catSVG({ fur, eyes, accessory, background }) {
  const furColor = FUR_COLORS[fur] || "#FFD9C2";
  const [bgA, bgB] = BG_GRADIENTS[background] || ["#EAF4FF", "#D6E9FF"];
  const gid = "g" + Math.random().toString(36).slice(2, 9);

  const eyeShapes = {
    "Sparkle Star": `
      <circle cx="78" cy="105" r="9" fill="#3B3560"/><circle cx="142" cy="105" r="9" fill="#3B3560"/>
      <circle cx="75" cy="101" r="3" fill="#fff"/><circle cx="139" cy="101" r="3" fill="#fff"/>
      <path d="M60 80 l4 8 8 4 -8 4 -4 8 -4 -8 -8 -4 8 -4z" fill="#FFD97D"/>`,
    "Anime Wink": `
      <circle cx="78" cy="105" r="10" fill="#3B3560"/><circle cx="75" cy="101" r="3" fill="#fff"/>
      <path d="M132 105 q10 -10 20 0" stroke="#3B3560" stroke-width="4" fill="none" stroke-linecap="round"/>`,
    "Heterochromia": `
      <circle cx="78" cy="105" r="9" fill="#8FC9F5"/><circle cx="75" cy="101" r="3" fill="#fff"/>
      <circle cx="142" cy="105" r="9" fill="#C9B6F5"/><circle cx="139" cy="101" r="3" fill="#fff"/>`,
    "Sleepy Blink": `
      <path d="M68 106 q10 8 20 0" stroke="#3B3560" stroke-width="4" fill="none" stroke-linecap="round"/>
      <path d="M132 106 q10 8 20 0" stroke="#3B3560" stroke-width="4" fill="none" stroke-linecap="round"/>`,
  };

  const accessoryShapes = {
    "Crown": `<path d="M75 55 L85 30 L100 50 L115 30 L125 55 Z" fill="#FFD97D" stroke="#FFC24B" stroke-width="2"/>
               <circle cx="85" cy="30" r="4" fill="#FF9B85"/><circle cx="100" cy="48" r="4" fill="#8FC9F5"/><circle cx="115" cy="30" r="4" fill="#C9B6F5"/>`,
    "Bow Tie": `<path d="M85 165 L100 155 L85 145 Z" fill="#FF9B85"/><path d="M115 165 L100 155 L115 145 Z" fill="#FF9B85"/><circle cx="100" cy="155" r="5" fill="#FF7A5C"/>`,
    "Round Glasses": `<circle cx="78" cy="105" r="16" fill="none" stroke="#3B3560" stroke-width="4"/><circle cx="142" cy="105" r="16" fill="none" stroke="#3B3560" stroke-width="4"/><line x1="94" y1="105" x2="126" y2="105" stroke="#3B3560" stroke-width="4"/>`,
    "Flower Crown": `<circle cx="72" cy="45" r="9" fill="#FFC9DE"/><circle cx="92" cy="35" r="9" fill="#DCCEFA"/><circle cx="112" cy="35" r="9" fill="#B9F2D9"/><circle cx="132" cy="45" r="9" fill="#FFD9C2"/>
                      <circle cx="72" cy="45" r="3" fill="#FFD97D"/><circle cx="92" cy="35" r="3" fill="#FFD97D"/><circle cx="112" cy="35" r="3" fill="#FFD97D"/><circle cx="132" cy="45" r="3" fill="#FFD97D"/>`,
    "None": "",
  };

  return `
  <svg viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg">
    <defs>
      <linearGradient id="${gid}" x1="0" y1="0" x2="1" y2="1">
        <stop offset="0%" stop-color="${bgA}"/>
        <stop offset="100%" stop-color="${bgB}"/>
      </linearGradient>
    </defs>
    <rect width="200" height="200" fill="url(#${gid})"/>
    <!-- ears -->
    <path d="M55 75 L40 30 L85 55 Z" fill="${furColor}"/>
    <path d="M145 75 L160 30 L115 55 Z" fill="${furColor}"/>
    <path d="M60 68 L52 42 L78 56 Z" fill="#fff" opacity="0.5"/>
    <path d="M140 68 L148 42 L122 56 Z" fill="#fff" opacity="0.5"/>
    <!-- head -->
    <ellipse cx="100" cy="120" rx="62" ry="55" fill="${furColor}"/>
    <!-- muzzle highlight -->
    <ellipse cx="100" cy="140" rx="30" ry="18" fill="#fff" opacity="0.55"/>
    <!-- eyes -->
    ${eyeShapes[eyes] || eyeShapes["Sparkle Star"]}
    <!-- nose + mouth -->
    <path d="M96 128 L104 128 L100 134 Z" fill="#FF9B85"/>
    <path d="M100 134 Q100 140 92 142 M100 134 Q100 140 108 142" stroke="#3B3560" stroke-width="2.5" fill="none" stroke-linecap="round"/>
    <!-- whiskers -->
    <line x1="30" y1="122" x2="62" y2="126" stroke="#3B3560" stroke-width="2" opacity="0.4"/>
    <line x1="30" y1="134" x2="62" y2="134" stroke="#3B3560" stroke-width="2" opacity="0.4"/>
    <line x1="170" y1="122" x2="138" y2="126" stroke="#3B3560" stroke-width="2" opacity="0.4"/>
    <line x1="170" y1="134" x2="138" y2="134" stroke="#3B3560" stroke-width="2" opacity="0.4"/>
    <!-- accessory -->
    ${accessoryShapes[accessory] || ""}
  </svg>`;
}

function rarityFromAttributes(attrs) {
  const r = (attrs || []).find(a => a.trait_type === "Rarity");
  return r ? r.value : "Common";
}
function traitValue(attrs, type) {
  const t = (attrs || []).find(a => a.trait_type === type);
  return t ? t.value : null;
}

// ---------------------------------------------------------------------------
// Toasts
// ---------------------------------------------------------------------------
function showToast(message, isError = false) {
  const stack = document.getElementById("toastStack");
  const el = document.createElement("div");
  el.className = "toast" + (isError ? " error" : "");
  el.textContent = message;
  stack.appendChild(el);
  setTimeout(() => el.remove(), 4200);
}

// ---------------------------------------------------------------------------
// Trait pickers
// ---------------------------------------------------------------------------
async function loadTraitOptions() {
  const res = await fetch("/api/traits");
  traitOptions = await res.json();
  selected.fur = traitOptions.fur[0];
  selected.eyes = traitOptions.eyes[0];
  selected.background = traitOptions.background[0];

  const container = document.getElementById("traitGroups");
  container.innerHTML = "";

  const groups = [
    { key: "fur", label: "Fur color", options: traitOptions.fur },
    { key: "eyes", label: "Eyes", options: traitOptions.eyes },
    { key: "accessory", label: "Accessory", options: traitOptions.accessory },
    { key: "background", label: "Background", options: traitOptions.background },
  ];

  groups.forEach(group => {
    const wrap = document.createElement("div");
    wrap.className = "trait-group";
    const label = document.createElement("span");
    label.className = "trait-group-label";
    label.textContent = group.label;
    wrap.appendChild(label);

    const chipsWrap = document.createElement("div");
    chipsWrap.className = "trait-chips";

    group.options.forEach(opt => {
      const chip = document.createElement("button");
      chip.type = "button";
      chip.className = "chip" + (selected[group.key] === opt ? " selected" : "");
      chip.textContent = opt;
      chip.addEventListener("click", () => {
        selected[group.key] = opt;
        chipsWrap.querySelectorAll(".chip").forEach(c => c.classList.remove("selected"));
        chip.classList.add("selected");
        updatePreview();
      });
      chipsWrap.appendChild(chip);
    });

    wrap.appendChild(chipsWrap);
    container.appendChild(wrap);
  });

  updatePreview();
}

function updatePreview() {
  const frame = document.getElementById("previewFrame");
  frame.innerHTML = catSVG(selected);
  const premium = [selected.fur, selected.eyes, selected.accessory].filter(
    t => !["Buttercream", "Sleepy Blink", "None"].includes(t)
  ).length;
  const rarity = ["Common", "Rare", "Epic", "Legendary"][Math.min(premium, 3)];
  document.getElementById("previewRarity").textContent = rarity;
}

// ---------------------------------------------------------------------------
// Stats
// ---------------------------------------------------------------------------
async function refreshStats() {
  const res = await fetch("/api/stats");
  const data = await res.json();
  document.getElementById("statBlock").textContent = data.blockHeight.toLocaleString();
  document.getElementById("statSupply").textContent = data.totalSupply;
  document.getElementById("statHolders").textContent = data.totalHolders;
  document.getElementById("statGas").textContent = data.gasPriceGwei + " gwei";
}

// ---------------------------------------------------------------------------
// Gallery
// ---------------------------------------------------------------------------
function shortAddr(addr) {
  if (!addr) return "—";
  return addr.slice(0, 6) + "…" + addr.slice(-4);
}

async function refreshGallery() {
  const res = await fetch("/api/tokens");
  const tokens = await res.json();
  const grid = document.getElementById("galleryGrid");

  if (!tokens.length) {
    grid.innerHTML = `<p class="empty-state">No kitties minted yet — be the first!</p>`;
    return;
  }

  grid.innerHTML = "";
  tokens.slice().reverse().forEach(t => {
    const attrs = t.metadata.attributes || [];
    const traits = {
      fur: traitValue(attrs, "Fur"),
      eyes: traitValue(attrs, "Eyes"),
      accessory: traitValue(attrs, "Accessory"),
      background: traitValue(attrs, "Background"),
    };
    const card = document.createElement("div");
    card.className = "nft-card";
    card.innerHTML = `
      <div class="cat-frame">${catSVG(traits)}</div>
      <h3>${escapeHtml(t.metadata.name || "Unnamed")}</h3>
      <div class="token-meta">#${t.tokenId} · ${shortAddr(t.owner)}</div>
      <div class="rarity-badge">${rarityFromAttributes(attrs)}</div>
    `;
    grid.appendChild(card);
  });
}

function escapeHtml(str) {
  const div = document.createElement("div");
  div.textContent = str;
  return div.innerHTML;
}

// ---------------------------------------------------------------------------
// Mint
// ---------------------------------------------------------------------------
document.getElementById("useDemoWallet").addEventListener("click", () => {
  document.getElementById("mintRecipient").value = DEMO_WALLET;
});

document.getElementById("mintForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  const button = document.getElementById("mintButton");
  button.disabled = true;
  const originalHTML = button.innerHTML;
  button.innerHTML = `<span class="mega-button-icon">⏳</span><span>Minting…</span>`;

  const payload = {
    name: document.getElementById("mintName").value.trim(),
    description: document.getElementById("mintDescription").value.trim(),
    recipient: document.getElementById("mintRecipient").value.trim(),
    ...selected,
  };

  try {
    const res = await fetch("/api/mint", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    const data = await res.json();
    if (!res.ok) {
      showToast(data.message || "Mint failed.", true);
    } else {
      showToast(`🎉 ${data.message}`);
      document.getElementById("mintForm").reset();
      await loadTraitOptions();
      await Promise.all([refreshGallery(), refreshStats(), refreshActivity()]);
    }
  } catch (err) {
    showToast("Network error while minting.", true);
  } finally {
    button.disabled = false;
    button.innerHTML = originalHTML;
  }
});

// ---------------------------------------------------------------------------
// Ledger lookup
// ---------------------------------------------------------------------------
document.getElementById("lookupButton").addEventListener("click", async () => {
  const id = document.getElementById("lookupTokenId").value;
  const resultEl = document.getElementById("lookupResult");
  if (!id) {
    resultEl.innerHTML = `<p class="result-error">Enter a token ID first.</p>`;
    return;
  }
  const res = await fetch(`/api/owner/${id}`);
  const data = await res.json();
  if (!res.ok) {
    resultEl.innerHTML = `<p class="result-error">${escapeHtml(data.message)}</p>`;
    return;
  }
  resultEl.innerHTML = `
    <div class="result-card">
      <div class="row"><span>Owner</span><span>${data.owner}</span></div>
      <div class="row"><span>Token URI</span><span>${data.tokenURI}</span></div>
      <div class="row"><span>Name</span><span>${escapeHtml(data.metadata.name || "—")}</span></div>
      <div class="row"><span>Rarity</span><span>${rarityFromAttributes(data.metadata.attributes)}</span></div>
      <div class="row"><span>Transfers</span><span>${data.history.length}</span></div>
    </div>`;
});

// ---------------------------------------------------------------------------
// Transfer
// ---------------------------------------------------------------------------
document.getElementById("transferForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  const resultEl = document.getElementById("transferResult");
  const payload = {
    tokenId: document.getElementById("transferTokenId").value,
    from: document.getElementById("transferFrom").value.trim(),
    to: document.getElementById("transferTo").value.trim(),
  };
  const res = await fetch("/api/transfer", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });
  const data = await res.json();
  if (!res.ok) {
    resultEl.innerHTML = `<p class="result-error">${escapeHtml(data.message)}</p>`;
    showToast(data.message, true);
  } else {
    resultEl.innerHTML = `<div class="result-card"><div class="row"><span>Status</span><span>Success</span></div><div class="row"><span>New owner</span><span>${data.newOwner}</span></div></div>`;
    showToast(`🔁 ${data.message}`);
    document.getElementById("transferForm").reset();
    await Promise.all([refreshGallery(), refreshStats(), refreshActivity()]);
  }
});

// ---------------------------------------------------------------------------
// Activity feed
// ---------------------------------------------------------------------------
async function refreshActivity() {
  const res = await fetch("/api/events");
  const events = await res.json();
  const list = document.getElementById("activityList");
  if (!events.length) {
    list.innerHTML = `<li class="empty-state">No events yet.</li>`;
    return;
  }
  list.innerHTML = "";
  events.forEach(ev => {
    const isMint = ev.from === "0x0000000000000000000000000000000000000000";
    const li = document.createElement("li");
    li.className = "activity-item";
    li.innerHTML = `
      <span class="activity-icon">${isMint ? "✨" : "🔁"}</span>
      <span class="activity-text">${isMint
        ? `Minted <strong>#${ev.tokenId}</strong> ${escapeHtml(ev.tokenName || "")} to ${shortAddr(ev.to)}`
        : `Transferred <strong>#${ev.tokenId}</strong> from ${shortAddr(ev.from)} to ${shortAddr(ev.to)}`}</span>
      <span class="activity-time">${new Date(ev.timestamp).toLocaleTimeString()}</span>
    `;
    list.appendChild(li);
  });
}

// ---------------------------------------------------------------------------
// Init
// ---------------------------------------------------------------------------
(async function init() {
  await loadTraitOptions();
  await Promise.all([refreshStats(), refreshGallery(), refreshActivity()]);
  setInterval(refreshActivity, 8000);
})();
